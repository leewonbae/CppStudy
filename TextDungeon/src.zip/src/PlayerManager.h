#pragma once

#include <string>
#include <memory>

class Player;
class UserInterfaceManager;

class PlayerManager
{
public:
PlayerManager(UserInterfaceManager* userinterfaceManagaer);
~PlayerManager();

Player* CreatePlayer();
	
private:
	UserInterfaceManager* _ptrUserInterfaceManager;

	std::unique_ptr<Player> _ptrPlayer;

};

