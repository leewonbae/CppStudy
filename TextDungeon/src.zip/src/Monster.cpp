#include "Monster.h"
#include "Player.h"

Monster::Monster(const std::string& name)
{
	_name = name;
	std::cout << "Monster ������ " << _name << std::endl;
}

Monster::~Monster()
{
	std::cout << "Monster �Ҹ��� " << _name << std::endl;
}

int Monster::AddDamage(int32_t damage)
{
	_healthPoint -= damage;
	std::cout << _ptrTargetPlayer->GetName() << " ��(��) " << damage << " ���� �߽��ϴ�." << std::endl;

	return _healthPoint;
}

void Monster::SetTaretPlayer(Player* targetPlayer)
{
	_ptrTargetPlayer = targetPlayer;
	std::cout << "targetPlayer Name" << _ptrTargetPlayer->GetName() << std::endl;
}


