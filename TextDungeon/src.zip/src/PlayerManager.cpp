#include "PlayerManager.h"

#include "UserInterfaceManager.h"

#include "Player.h"

PlayerManager::PlayerManager(UserInterfaceManager* userinterfaceManagaer)
	:_ptrUserInterfaceManager(userinterfaceManagaer)
{
	_ptrUserInterfaceManager->PrintText("PlayerManager ������");
}

PlayerManager::~PlayerManager()
{
	_ptrUserInterfaceManager->PrintText("PlayerManager �Ҹ���");
}

Player* PlayerManager::CreatePlayer()
{
	auto playerName =_ptrUserInterfaceManager->GetAskAndInputString("�÷��̾� �̸��� �Է��ϼ���: ");

	_ptrPlayer = std::make_unique<Player>(playerName);

	return _ptrPlayer.get();
}
